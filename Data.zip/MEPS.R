install.packages("readr")
library(readr)
# Import MEPS Data
meps_path <- "/Users/aaronmedina/School/Data Science & Statistical Learning - SP25/Group Project/h243.dat"
source("https://meps.ahrq.gov/mepsweb/data_stats/download_data/pufs/h243/h243ru.txt")
head(h243)